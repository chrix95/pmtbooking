<header class="header" role="banner">
  <div class="wrap">
    <!-- Logo -->
    <div class="logo">
      <a href="<?php echo e(route('welcome')); ?>" title="Transfers"><img src="<?php echo e(asset('ui/images/transfers.png')); ?>" alt="Peace Mass Transit" width="170px" /></a>
    </div>
    <!-- //Logo -->

    <!-- Main Nav -->
    <nav role="navigation" class="main-nav">
      <ul>
        <li <?php if(active('/')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(route('welcome')); ?>" title="Home">Home</a>
        </li>
        <li <?php if(active('about')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(route('about')); ?>" title="About">About</a>
        </li>
        <li <?php if(active('faqs')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(route('faqs')); ?>" title="About">FAQs</a>
        </li>
        <li <?php if(active('terminal')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(route('terminal')); ?>" title="Terminal">Terminals</a>
        </li>
        <li <?php if(active('contact')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(route('contact')); ?>" title="Contact">Contact</a>
        </li>
        <li <?php if(active('booking.search')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(route('booking.search')); ?>" title="Contact">Booking</a>
        </li>
      </ul>
    </nav>
    <!-- //Main Nav -->
  </div>
</header><?php /**PATH C:\wamp64\www\pmt\resources\views/_partials/header.blade.php ENDPATH**/ ?>