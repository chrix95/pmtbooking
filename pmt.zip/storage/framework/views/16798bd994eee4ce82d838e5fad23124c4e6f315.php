<?php $__env->startSection('pageTitle', 'Booking Status'); ?>
<?php $__env->startSection('page', 'Booking Status'); ?>
<?php $__env->startSection('content'); ?>
  <booking-status></booking-status>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
  <script>
    $(function() {
      $( "#datepicker" ).datepicker();
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pmt\resources\views/booking/status.blade.php ENDPATH**/ ?>