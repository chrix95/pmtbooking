<link href=" <?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('ui/css/styler.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('ui/css/theme-pink.css')); ?>" id="template-color" />
<link rel="stylesheet" href="<?php echo e(asset('ui/themes/jquery-ui.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('ui/css/jquery-ui.theme.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('ui/css/style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('ui/css/animate.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('ui/css/icons.css')); ?>" />
<link href="http://fonts.googleapis.com/css?family=Raleway:400,500,600,700|Montserrat:400,700" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="<?php echo e(asset('ui/images/favicon.png')); ?>" /><?php /**PATH C:\wamp64\www\pmt\resources\views/layouts/css.blade.php ENDPATH**/ ?>