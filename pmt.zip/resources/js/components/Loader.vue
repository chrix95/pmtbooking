<template>
    <img src="ui/images/loading.gif" alt="General Loader" width="20%"/>
</template>

<script>
    export default {
        mounted() {
        },
        data() {
            return {
            }
        },
        methods: {
            
        }
    }
</script>
