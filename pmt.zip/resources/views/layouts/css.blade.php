<link href=" {{ mix('css/app.css') }}" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('ui/css/styler.css') }}" />
<link rel="stylesheet" href="{{ asset('ui/css/theme-pink.css') }}" id="template-color" />
<link rel="stylesheet" href="{{ asset('ui/themes/jquery-ui.css') }}">
<link rel="stylesheet" href="{{ asset('ui/css/jquery-ui.theme.css') }}" />
<link rel="stylesheet" href="{{ asset('ui/css/style.css') }}" />
<link rel="stylesheet" href="{{ asset('ui/css/animate.css') }}" />
<link rel="stylesheet" href="{{ asset('ui/css/icons.css') }}" />
<link href="http://fonts.googleapis.com/css?family=Raleway:400,500,600,700|Montserrat:400,700" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="{{ asset('ui/images/favicon.png') }}" />